package com.projectms.service;

import com.projectms.entity.*;
import com.projectms.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Service
public class TaskService {

    @Autowired private TaskRepository taskRepository;
    @Autowired private ProjectRepository projectRepository;
    @Autowired private MilestoneRepository milestoneRepository;
    @Autowired private UserRepository userRepository;
    @Autowired private TaskUpdateRepository taskUpdateRepository;

    public List<Task> getTasksByProject(Long projectId) {
        Project project = projectRepository.findById(projectId)
                .orElseThrow(() -> new RuntimeException("Project not found"));
        return taskRepository.findByProject(project);
    }

    public List<Task> getTasksByMilestone(Long milestoneId) {
        Milestone milestone = milestoneRepository.findById(milestoneId)
                .orElseThrow(() -> new RuntimeException("Milestone not found"));
        return taskRepository.findByMilestone(milestone);
    }

    public List<Task> getTasksByUser(User user) {
        return taskRepository.findByAssignedTo(user);
    }

    public List<Task> getMyProjectTasks(Long projectId, User user) {
        Project project = projectRepository.findById(projectId)
                .orElseThrow(() -> new RuntimeException("Project not found"));
        return taskRepository.findByProjectAndAssignedTo(project, user);
    }

    public Task getTaskById(Long id) {
        return taskRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Task not found: " + id));
    }

    @Transactional
    public Task createTask(Map<String, Object> req, User creator) {
        Long projectId = Long.valueOf(req.get("projectId").toString());
        Project project = projectRepository.findById(projectId)
                .orElseThrow(() -> new RuntimeException("Project not found"));

        Milestone milestone = null;
        if (req.get("milestoneId") != null) {
            milestone = milestoneRepository.findById(Long.valueOf(req.get("milestoneId").toString()))
                    .orElseThrow(() -> new RuntimeException("Milestone not found"));
        }

        User assignedTo = null;
        if (req.get("assignedToId") != null) {
            assignedTo = userRepository.findById(Long.valueOf(req.get("assignedToId").toString()))
                    .orElseThrow(() -> new RuntimeException("Assigned user not found"));
        }

        Task task = Task.builder()
                .project(project)
                .milestone(milestone)
                .title((String) req.get("title"))
                .description((String) req.get("description"))
                .assignedTo(assignedTo)
                .createdBy(creator)
                .status(Task.TaskStatus.TODO)
                .priority(req.get("priority") != null ? (Integer) req.get("priority") : 2)
                .dueDate(req.get("dueDate") != null ? LocalDate.parse((String) req.get("dueDate")) : null)
                .estimatedHours(req.get("estimatedHours") != null ? (Integer) req.get("estimatedHours") : 0)
                .build();

        return taskRepository.save(task);
    }

    @Transactional
    public Task updateTask(Long id, Map<String, Object> req, User actor) {
        Task task = getTaskById(id);

        if (req.containsKey("title")) task.setTitle((String) req.get("title"));
        if (req.containsKey("description")) task.setDescription((String) req.get("description"));
        if (req.containsKey("status")) {
            Task.TaskStatus status = Task.TaskStatus.valueOf((String) req.get("status"));
            task.setStatus(status);
            if (status == Task.TaskStatus.COMPLETED) task.setCompletedDate(LocalDate.now());
        }
        if (req.containsKey("priority")) task.setPriority((Integer) req.get("priority"));
        if (req.containsKey("dueDate") && req.get("dueDate") != null)
            task.setDueDate(LocalDate.parse((String) req.get("dueDate")));
        if (req.containsKey("estimatedHours")) task.setEstimatedHours((Integer) req.get("estimatedHours"));
        if (req.containsKey("actualHours")) task.setActualHours((Integer) req.get("actualHours"));
        if (req.containsKey("assignedToId") && req.get("assignedToId") != null) {
            User assignee = userRepository.findById(Long.valueOf(req.get("assignedToId").toString()))
                    .orElseThrow(() -> new RuntimeException("User not found"));
            task.setAssignedTo(assignee);
        }
        if (req.containsKey("milestoneId") && req.get("milestoneId") != null) {
            Milestone milestone = milestoneRepository.findById(Long.valueOf(req.get("milestoneId").toString()))
                    .orElseThrow(() -> new RuntimeException("Milestone not found"));
            task.setMilestone(milestone);
        }
        return taskRepository.save(task);
    }

    @Transactional
    public void deleteTask(Long id) {
        taskRepository.deleteById(id);
    }

    @Transactional
    public TaskUpdate addUpdate(Long taskId, String content, int progress, String type, User user) {
        Task task = getTaskById(taskId);

        // Auto-update task status based on progress
        if (progress == 100) task.setStatus(Task.TaskStatus.COMPLETED);
        else if (progress > 0 && task.getStatus() == Task.TaskStatus.TODO)
            task.setStatus(Task.TaskStatus.IN_PROGRESS);
        taskRepository.save(task);

        TaskUpdate update = TaskUpdate.builder()
                .task(task)
                .user(user)
                .content(content)
                .progressPercent(progress)
                .type(TaskUpdate.UpdateType.valueOf(type))
                .build();
        return taskUpdateRepository.save(update);
    }

    public List<TaskUpdate> getTaskUpdates(Long taskId) {
        Task task = getTaskById(taskId);
        return taskUpdateRepository.findByTaskOrderByCreatedAtDesc(task);
    }

    public Map<String, Object> getEmployeeStats(User user) {
        long total = taskRepository.findByAssignedTo(user).size();
        long completed = taskRepository.countByAssignedToAndStatus(user, Task.TaskStatus.COMPLETED);
        long inProgress = taskRepository.countByAssignedToAndStatus(user, Task.TaskStatus.IN_PROGRESS);
        long blocked = taskRepository.countByAssignedToAndStatus(user, Task.TaskStatus.BLOCKED);
        return Map.of("totalTasks", total, "completedTasks", completed, "inProgress", inProgress, "blocked", blocked);
    }
}
