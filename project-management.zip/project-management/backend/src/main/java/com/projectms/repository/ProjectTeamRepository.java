package com.projectms.repository;

import com.projectms.entity.ProjectTeam;
import com.projectms.entity.Project;
import com.projectms.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface ProjectTeamRepository extends JpaRepository<ProjectTeam, Long> {
    List<ProjectTeam> findByProject(Project project);
    List<ProjectTeam> findByUser(User user);
    Optional<ProjectTeam> findByProjectAndUser(Project project, User user);
    boolean existsByProjectAndUser(Project project, User user);
    void deleteByProjectAndUser(Project project, User user);
}
