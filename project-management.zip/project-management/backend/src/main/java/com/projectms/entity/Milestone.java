package com.projectms.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "milestones")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Milestone {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "project_id", nullable = false)
    private Project project;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private MilestonePhase phase;

    @Column(nullable = false)
    private String title;

    @Column(columnDefinition = "TEXT")
    private String description;

    private int orderIndex; // 1-6 ordering

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private MilestoneStatus status = MilestoneStatus.PENDING;

    private LocalDate dueDate;
    private LocalDate completedDate;

    private int progressPercent; // 0-100

    @Column(updatable = false)
    @Builder.Default
    private LocalDateTime createdAt = LocalDateTime.now();

    private LocalDateTime updatedAt;

    @PreUpdate
    public void preUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

    public enum MilestonePhase {
        DOCUMENTS_AND_INFORMATION_COLLECTION,
        DESIGN_THE_APPLICATION,
        DEVELOPMENT,
        TESTING,
        REVIEW,
        PUBLISH
    }

    public enum MilestoneStatus {
        PENDING, IN_PROGRESS, COMPLETED, BLOCKED
    }
}
