package com.projectms.repository;

import com.projectms.entity.Milestone;
import com.projectms.entity.Project;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface MilestoneRepository extends JpaRepository<Milestone, Long> {
    List<Milestone> findByProjectOrderByOrderIndex(Project project);
    List<Milestone> findByProjectAndStatus(Project project, Milestone.MilestoneStatus status);
    long countByProjectAndStatus(Project project, Milestone.MilestoneStatus status);
}
