package com.projectms.repository;

import com.projectms.entity.TaskUpdate;
import com.projectms.entity.Task;
import com.projectms.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface TaskUpdateRepository extends JpaRepository<TaskUpdate, Long> {
    List<TaskUpdate> findByTaskOrderByCreatedAtDesc(Task task);
    List<TaskUpdate> findByUserOrderByCreatedAtDesc(User user);
    List<TaskUpdate> findByTaskAndUser(Task task, User user);
}
