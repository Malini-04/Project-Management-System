package com.projectms.repository;

import com.projectms.entity.Project;
import com.projectms.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ProjectRepository extends JpaRepository<Project, Long> {
    List<Project> findByDepartment(User.Department department);
    List<Project> findByManager(User manager);
    List<Project> findByCreatedBy(User createdBy);
    List<Project> findByStatus(Project.ProjectStatus status);

    @Query("SELECT p FROM Project p JOIN ProjectTeam pt ON pt.project = p WHERE pt.user = :user")
    List<Project> findProjectsByTeamMember(@Param("user") User user);

    @Query("SELECT COUNT(p) FROM Project p WHERE p.department = :dept")
    long countByDepartment(@Param("dept") User.Department dept);
}
