package com.projectms.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "task_updates")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TaskUpdate {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "task_id", nullable = false)
    private Task task;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(columnDefinition = "TEXT", nullable = false)
    private String content;

    private int progressPercent; // 0-100

    @Enumerated(EnumType.STRING)
    private UpdateType type; // PROGRESS_UPDATE, BLOCKER, FEEDBACK, COMPLETION

    @Column(updatable = false)
    @Builder.Default
    private LocalDateTime createdAt = LocalDateTime.now();

    public enum UpdateType {
        PROGRESS_UPDATE, BLOCKER, FEEDBACK, COMPLETION
    }
}
